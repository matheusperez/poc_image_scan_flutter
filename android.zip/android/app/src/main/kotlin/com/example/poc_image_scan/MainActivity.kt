package com.example.poc_image_scan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
